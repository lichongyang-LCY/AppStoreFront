# 项目架构与代码结构说明（自动生成）

此文件为本仓库的结构与设计说明，基于仓库中源码分析而写。目标是为开发者快速理解项目目录、主要模块、命名/样式规范，以及对关键组件（示例：`Button.svelte`）的深入解读。

> 注意：本仓库是从线上 App Store 提取的前端源代码归档（Svelte + TypeScript）。某些私有包引用（如 `@amp/*`）为苹果内部样式/工具链包的命名空间。

---

## 一、顶层目录（概览）

仓库根目录 `d:/dragon/page/apps.apple.com-main/` 下主要项：

- `api/` — API 相关代码与资源（请求逻辑或接口实现/配置）。
- `assets/` — 静态资源：打包后的 JS/CSS、字体、图标、sourcemap 相关文件等。
- `node_modules/` — 依赖（若存在，本仓库可能为归档，依赖未全部包含）。
- `README.md` — 仓库整体说明（归档来源/目的）。
- `shared/` — 可在多个应用/地区复用的共享模块（组件库、工具库、localization 等）。
- `src/` — 主应用源码（Svelte + TypeScript）。
- `us/` — 区域（region）定制代码，例如 `us/iphone/`。

---

## 二、`src/` 目录结构（主要子项）

`src/` 包含应用入口与核心模块：

- `App.svelte` — 应用根组件，负责 global 布局、导航、页面分发等。
- `bootstrap.ts` — 引导函数：初始化 Jet、路由、i18n 等运行时上下文。
- `browser.ts` — 浏览器端启动逻辑（若存在）。
- `components/` — 以功能划分的界面组件目录（如 `navigation/`、`structure/`、`hero/`、`Shelf/` 等）。
- `config/` — 应用级配置（例 `config/build.ts` 提供 `BUILD` 常量）。
- `constants/` — 常量文件（storefront、footer items 等）。
- `context/` — 布局或可访问上下文的构造/工具。
- `jet/` — 应用运行时（Jet）相关模块：路由、intent 构建、依赖注入等。
- `sf-symbols/` — SFSymbol 或图标相关资源。
- `stores/` — Svelte store（i18n、modal、metrics 等）。
- `utils/` — 项目工具函数（locale、metrics、portal、file-size 等）。

---

## 三、`shared/` 目录（高复用模块）

`shared/` 包含公司/组织级别的可共享代码：

- `apps-common/` — 多个 app 共同使用的逻辑。
- `components/` — 共享组件库（有自己的 `src/` 目录）。
- `featurekit/` — 功能模块包。
- `fonts/`, `localization/`, `logger/`, `metrics-8/`, `storefronts/`, `utils/` — 对应功能的共享实现。

具体发现：`shared/components/src/components/` 下组织了很多组件子目录，例如：

- `Artwork/`、`buttons/`、`Footer/`、`Navigation/`、`Shelf/`、`Modal/`、`SearchInput/` 等。

`shared/components` 下的 `src` 目录内部还包含 `actions/`, `stores/`, `utils/` 等，表示共享组件包自身也保持完整的分层结构用于自包含开发与复用。

---

## 四、`assets/`（静态构建产物）

assets 下包含若干打包好的 JS/CSS，以及 fonts/icons：例如 `index*.js`、`index*.css`、`translations*.js`、`version*.js`，以及 `focus-visible` polyfill、favicon、icons 等。

---

## 五、命名与风格约定（总结）

- 组件文件与组件名：PascalCase（如 `App.svelte`、`PageResolver.svelte`、`Button.svelte`）。
- 目录/模块：小写或复数（`components/`, `utils/`, `stores/`）。
- 类型/接口：PascalCase（TypeScript）。
- 路径别名：`~` 指向项目源（例如 `~/config/build`）；私有包以 `@amp/...` 命名。
- CSS 命名：BEM-like（`block__element`），修饰符用 `--`（`block--modifier`）。SASS 与 CSS custom properties（`--xxx`）并用。
- Props/events/slots：组件 props 使用 camelCase；事件通过 `createEventDispatcher` 发出（例如 `buttonClick`）。

---

## 六、核心运行时/架构要点

- "Jet" 运行时：集中式路由、intent/action 分发和依赖注入，`bootstrap.ts` 中通过 `Jet.load()` 初始化。
- SSR/CSR 双模式：`App.svelte` 显式处理 page 可能为 Promise（客户端）或同步对象（SSR），并把 Promise reject 转为错误页面 intent。
- i18n 在引导阶段初始化（`setupI18n`），并与 Jet locale 绑定。
- 组件主题化：大量使用 CSS 变量以支持主题与样式覆盖。

---

## 七、关键组件深入（示例：`Button.svelte`）

文件位置：

```
shared/components/src/components/buttons/Button.svelte
```

作用概述：

- 这是共享组件库中的基础按钮组件，封装了样式、键盘交互、焦点管理、slot 插槽（图标在前/后）、以及多种视觉风格（primary/secondary/tertiary/alert/pill/text/socialProfile）。

主要 API（props / events / slots）：

- Props:
  - `buttonStyle: string | null` — 指定按钮风格（内部映射到 `buttonType`，允许值包括 `buttonA`, `buttonB`, `buttonD`, `alertButton`, `alertButtonSecondary`, `pillButton`, `socialProfileButton`, `textButton` 等）。
  - `makeFocused: boolean` — 是否在 mount 后自动聚焦该按钮。
  - `ariaLabel: string | null` — 传递给 button 元素的 `aria-label`。
  - `type: 'button' | 'submit'` — button 的 type 属性。
  - `disabled: boolean` — 禁用状态。
  - `buttonElement: HTMLButtonElement` — bind:this 用于外部引用（可被父组件控制 focus 等）。
- Events:
  - 组件通过 Svelte 的 `createEventDispatcher` 派发 `buttonClick` 事件（当 button 被 click 或特定 keyup（Enter/Escape）触发时）。
- Slots:
  - 默认 slot：用于按钮文本或自定义内容。
  - `slot name="icon-before"`：在文本前渲染图标。
  - `slot name="icon-after"`：在文本后渲染图标。

实现细节要点：

- 使用 `class:primary={buttonType === 'buttonA'}` 等 Svelte class directive 根据 `buttonType` 动态添加根级修饰符类，样式通过 `.primary .secondary .tertiary` 等选择器实现。
- 使用 `makeSafeTick()` 在 `onMount` 后安全触发 `buttonElement.focus()`（防止 race 或在 SSR/CSR 切换时错误调用）。
- 键盘支持：`on:keyup` 监听 Enter 与 Escape 并触发 `handleButtonClick()`。
- 样式：采用 SCSS，并 `@use` 若干共享样式包（例如 `@amp/web-shared-styles/app/core/globalvars`），样式主要通过 CSS custom properties（`--buttonBackgroundColor`, `--buttonTextColor` 等）进行可配置。

示例用法：

```svelte
<Button buttonStyle="buttonA" ariaLabel="保存" on:buttonClick="{handleSave}">保存</Button>

<Button buttonStyle="textButton">了解更多</Button>

<Button buttonStyle="pillButton">
  <span slot="icon-before">...</span>
  Follow
</Button>
```

注意点／边缘情况：

- `buttonStyle` 最终被 cast 为 union 类型 `ButtonType`（实现中用 `$: buttonType = buttonStyle as ButtonType`）。如果传入未知样式则按默认样式处理。
- focus 管理与 SSR/CSR：`makeSafeTick` 的使用确保只在客户端安全地调用 focus。
- disabled 状态通过 `[disabled]` CSS 选择器处理（包括暗色模式下的变更）。

---

## 八、建议（按优先级）

1. 在 `shared/components` 下为组件生成简短的 API 文档（每个组件放置 `README.md`，列出 props / events / slots / 示例）。
2. 在仓库根添加 `package.json` 和运行说明（如果目标是可运行仓库），或者在 `README.md` 明确标注这是归档并提供复现/运行建议。
3. 为共享样式变量编写一页样式变量清单（哪些 `--` 变量可覆盖），便于 design tokens 管理。
4. 添加 lint 与 type-check 脚本（如 `npm run typecheck`）以及少量单元测试（Button 的交互/slot/disabled 测试）。

---

## 九、如何扩展或复用本说明

若需更全面的、可机器解析的目录树（含每个文件行数、导出符号列表等），可以运行仓库扫描脚本来自动生成：

- 扫描脚本要点：递归列出文件 -> 对每个 `.svelte`, `.ts` 文件做简单 AST/文本扫描 -> 提取 `export let`、事件 `dispatch('...')`、slot 名称等。

---

## 十、结尾

以上为本仓库的结构和关键组件（以 `Button.svelte` 为样本）的详细说明，已写入此 `ARCHITECTURE.md`。如果你要我：

- 进一步对所有组件生成 API 文档（自动化），或者
- 为 `shared/components` 增加每个组件的 `README.md`，或者
- 生成可运行的 `package.json` / 启动脚本 模板（基于项目依赖与习惯），
