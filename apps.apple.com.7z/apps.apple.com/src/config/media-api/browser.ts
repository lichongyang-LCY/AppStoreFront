export const MEDIA_API_JWT = import.meta.env.BROWSER_MEDIA_API_JWT ?? '';
