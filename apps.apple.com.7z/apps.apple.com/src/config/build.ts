export const BUILD = process.env.VERSION as string;
