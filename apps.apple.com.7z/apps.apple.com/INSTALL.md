## 安装与运行（本地预览指南）

这个项目是一份从线上提取的 Svelte/TypeScript 前端归档。仓库同时包含已编译的静态产物（`assets/`、`us/` 等）和源码（`src/`、`shared/`）。下面给出两种常用的本地运行方式：快速静态预览（推荐，零构建）和完整版源码运行（需补齐依赖与私有包）。

---

### 方式 A — 快速静态预览（推荐）

目的：直接预览仓库中已编译的 HTML/CSS/JS（无需安装 Node 或构建）。

步骤（PowerShell）：

```powershell
# 进入仓库根目录（示例）
Set-Location -Path 'd:\dragon\page\apps.apple.com-main'

# 启动一个简单的静态 HTTP 服务器（在 8080 端口）
python -m http.server 8080

# 在浏览器中打开（示例页面）
# http://localhost:8080/us/iphone/today.html
```

说明：我已在仓库根启动并测试过该静态服务器。如果浏览器仍然报 404，可能是 HTML 引用的资源名与 `assets/` 中实际文件名不一致（例如 HTML 请求 `/assets/index~B87DnNzwx-.js` 但磁盘上是 `indexB87DnNzwx-.js`）。为方便本地预览，我已为部分常见的 tilde (~) 变体创建了文件副本，并在仓库根添加了一个最小 `manifest.json`（供 `/manifest.json` 请求使用）。

已创建的兼容文件（示例）：

- `assets/index~B87DnNzwx-.js`（从 `assets/indexB87DnNzwx-.js` 复制）
- `assets/index~C-lllyUtRG.css`（从 `assets/indexC-lllyUtRG.css` 复制）
- `manifest.json`（仓库根，最小 PWA manifest）

如果你仍然看到 404，请在终端中查看服务器日志，它会显示缺失的路径。我可以帮你自动为这些引用创建兼容副本，或修改 HTML 指向现有文件名（后者有破坏性）。

---

### 方式 B — 从源码运行（开发环境，需构建）

目的：使用 Svelte/TypeScript 源码进行热重载开发或重新构建产物。注意：仓库引用了私有包（例如 `@amp/*`），可能无法直接从公共 registry 安装。

主要步骤（概要）：

1. 安装 Node.js（建议 v18+）并在 PowerShell 中确认 `node` 和 `npm` 可用。
2. 在仓库根创建一个 `package.json`（示例见下）。
3. 安装必要的依赖（例如 `svelte`, `vite`, `typescript`, `sass` 等）并处理 `@amp/*` 私有包（本地 stub、私有 registry 或替换）。
4. 运行 `npm run dev`（或你在 `package.json` 中定义的脚本）。

示例 `package.json`（供参考 — 需要按项目实际情况调整）:

```json
{
  "name": "appstore-local",
  "private": true,
  "version": "0.0.0",
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "preview": "vite preview"
  },
  "devDependencies": {
    "vite": "^5.0.0",
    "svelte": "^4.0.0",
    "@sveltejs/vite-plugin-svelte": "^2.0.0",
    "typescript": "^5.0.0",
    "sass": "^1.0.0"
  }
}
```

重要提示：

- 私有包 `@amp/*`：如果代码中大量 `import '@amp/...'`，你需要一个可访问的 registry 或在 `node_modules` 中放置本地实现（stub）。我可以帮你生成最小的本地 stub 包来满足构建，但这可能只够让项目启动而不保证所有功能完好。
- 构建时间和依赖大小：安装依赖和首次构建会花时间（取决于网络和硬盘）。

示例安装与启动（PowerShell）：

```powershell
Set-Location -Path 'd:\dragon\page\apps.apple.com-main'
# 如果你已经添加了 package.json
npm install
npm run dev
```

### 快速故障排查

- 查看服务器日志：运行静态服务器时，PowerShell 窗口会打印所有请求与状态码（200/304/404）。
- 查找还缺失的资源（PowerShell 快速脚本）：

```powershell
# 在仓库中查找 HTML/JS/CSS 里引用的 /assets/... 路径
Get-ChildItem -Recurse -Include *.html,*.js,*.css -File |
  Select-String -Pattern '/assets/[^"\'\)\s>]+' -AllMatches |
  ForEach-Object { $_.Matches } | ForEach-Object { $_.Value } | Sort-Object -Unique
```
